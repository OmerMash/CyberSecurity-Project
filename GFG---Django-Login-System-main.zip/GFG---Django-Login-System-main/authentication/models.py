from django.db import models
from django.db.models.fields import CharField

class Users(models.Model):
    username=CharField(max_length=40)
    password=CharField(max_length=10)
    password2=CharField(max_length=10)
    email=CharField(max_length=70)