from django.contrib.auth.password_validation import get_password_validators
from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseForbidden
from django.contrib.auth.models import User
from django.contrib import messages
from django.core.mail import EmailMessage, send_mail
from geeksforgeeks import settings
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from .models import Users
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from django.utils.encoding import force_bytes, force_text
from django.contrib.auth import authenticate, login, logout
from . tokens import generate_token

from django.contrib.auth import password_validation
import random


# Create your views here.
def home(request):
    return render(request, "authentication/index.html")

def signup(request):
    if request.method == "POST":
        username = request.POST['username']
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']
        #(password_validation.validate_password(pass2, None)!=None):
        from django.contrib.auth.password_validation import validate_password
        from django.core.exceptions import ValidationError
        if (validate_password(pass2, username)):
            messages.error(request, "Username must be under 10 charcters!!")




        if len(username)>20:
            messages.error(request, "Username must be under 20 charcters!!")
            return redirect('home')
        
        if pass1 != pass2:
            messages.error(request, "Passwords are not equal")
            return redirect('home')
        
        if not username.isalnum():
            messages.error(request, "Username must be Alpha-Numeric!!")
            return redirect('home')
        
        #myuser = User.objects.create_user(username, email, pass1)
        Users.objects.create(username=username, email=email, password=pass1,password2=pass2)

        #myuser.first_name = fname
        #myuser.last_name = lname
        # myuser.is_active = False
        #myuser.is_active = False
        #myuser.save()

        

        

        
        
    return render(request, "authentication/signup.html")


def activate(request,uidb64,token):
    try:
        uid = force_text(urlsafe_base64_decode(uidb64))
        myuser = User.objects.get(pk=uid)
    except (TypeError,ValueError,OverflowError,User.DoesNotExist):
        myuser = None

    if myuser is not None and generate_token.check_token(myuser,token):
        myuser.is_active = True
        # user.profile.signup_confirmation = True
        myuser.save()
        login(request,myuser)
        messages.success(request, "Your Account has been activated!!")
        return redirect('signin')
    else:
        return render(request,'activation_failed.html')


def signin(request):
    if request.method == 'POST':
        username = request.POST['username']
        pass1 = request.POST['pass1']

        
        #user = authenticate(username=username, password=pass1)
        #from django.contrib.auth.models import User
        check_if_user_exists = Users.objects.filter(username=username, password=pass1).exists()
        if check_if_user_exists:
            messages.error(request, "Logged In Sucessfully!!")
        else:
            return redirect('home')
        # this user is valid, do what you want to do
        
  #      if user is not None:
  #          login(request, user)
  #          fname = user.first_name
            # messages.success(request, "Logged In Sucessfully!!")
            #return render(request, "authentication/index.html",{"fname":fname})
        #else:
        #    messages.error(request, "Bad Credentials!!")
        #    return redirect('home')
    
    return render(request, "authentication/signin.html")


def signout(request):
    logout(request)
    messages.success(request, "Logged Out Successfully!!")
    return redirect('home')

def change(request):
    if request.method == "POST":
        username = request.POST['username']
        print(username)
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']
        email = request.POST['email']
        print(email)

        for p in Users.objects.raw('SELECT * FROM authentication_Users WHERE username=\'' + username + "'" +'and email=\'' + email +  "'"
                                   + 'and password=\'' + pass1 +  "'"):
            print(p)
            p.password = pass2
            p.password2= pass2
            p.save()
            #p.update(password=pass2)
        #Users.objects.raw('update authentication_users set password =\'' + pass2+"'" where username = ''')


        #usr = Users.objects.raw('SELECT * FROM Users_username')

        #usr = Users.objects.raw('SELECT * FROM Users WHERE username=\''+username+"'")

        #usr.password(pass2)
        #usr.password2(pass2)
    return render(request, "authentication/change.html")

def forget(request):
    if request.method == "POST":
        email = request.POST['email']
        print(request)
        code=str(random.randint(100, 999))
        subject= "Code for confirmation"
        message= "Hello , your code is:"+code
        from_email=settings.EMAIL_HOST_USER
        to_list=[email]
        send_mail(subject, message,from_email,to_list, fail_silently=False)
        print("her")
        messages.success(request, "Send mail!!")

    return render(request, "authentication/forget.html")

