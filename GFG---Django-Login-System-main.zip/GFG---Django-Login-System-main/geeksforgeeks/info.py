from django.core.mail.backends import smtp

EMAIL_USE_TLS=True
EMAIL_HOST="smtp.gmail.com"
EMAIL_HOST_USER='lior19970@gmail.com'
EMAIL_HOST_PASSWORD='siawfgbtdqjxuvib'
EMAIL_PORT=587